#!/usr/bin/python
# -*- coding: utf-8 -*-

from sugar3.activity import bundlebuilder
bundlebuilder.start()
