#!/usr/bin/env python
# -*- coding: utf-8 -*-

from distutils.core import setup

setup(
	name = "JAMTank",
	version = "2.0.0",
	author = "Flavio Danesse",
	author_email = "fdanesse@gmail.com",
	url = "",
	license = "GPL3",

	scripts = ["jamtank_run", "jamtank_uninstall"],

	py_modules = ["JAMTank"],

	data_files =[
		("/usr/share/applications/", ["JAMTank.desktop"]),
		("",[
			"MANIFEST",
			"setup.py",
			"SelectWidgets.py",
			"JAMTank.py",
			"setup.cfg",
			"Estilo.css",
			"IntroWidget.py",
			"JAMTank.desktop",
			"SugarJAMTank.py",
			"SelectClient.py",
			"jamtank_run",
			"COPYING",
			"jamtank_uninstall",
			"Globales.py",
			"SelectServer.py",
			"AUTHORS"]),

		("Explosion/",[
			"Explosion/02.png",
			"Explosion/05.png",
			"Explosion/12.png",
			"Explosion/01.png",
			"Explosion/11.png",
			"Explosion/13.png",
			"Explosion/10.png",
			"Explosion/04.png",
			"Explosion/07.png",
			"Explosion/09.png",
			"Explosion/15.png",
			"Explosion/08.png",
			"Explosion/03.png",
			"Explosion/06.png",
			"Explosion/14.png",
			"Explosion/16.png"]),

		("activity/",[
			"activity/JAMTank.svg",
			"activity/activity.info"]),

		("SinglePlayer/",[
			"SinglePlayer/__init__.py",
			"SinglePlayer/Jugador.py",
			"SinglePlayer/GameWidget.py",
			"SinglePlayer/Enemigo.py",
			"SinglePlayer/Juego.py"]),

		("Audio/",[
			"Audio/motor1.ogg",
			"Audio/disparo.ogg",
			"Audio/motor2.ogg",
			"Audio/explosion.ogg",
			"Audio/Juego.ogg"]),

		("Tanques/",[
			"Tanques/tanque-7.png",
			"Tanques/tanque-6.png",
			"Tanques/tanque-3.png",
			"Tanques/tanque-5.png",
			"Tanques/tanque-2.png",
			"Tanques/tanque-8.png",
			"Tanques/tanque-4.png",
			"Tanques/tanque-1.png",
			"Tanques/tanque-9.png"]),

		("Mapas/",[
			"Mapas/fondo2.png",
			"Mapas/fondo0.png",
			"Mapas/fondo1.png"]),

		("Iconos/",[
			"Iconos/bala.png",
			"Iconos/jamtank.svg"]),

		("Multiplayer/Network/",[
			"Multiplayer/Network/Client.py",
			"Multiplayer/Network/__init__.py",
			"Multiplayer/Network/Descripciones.txt",
			"Multiplayer/Network/Server.py"]),

		("Multiplayer/",[
			"Multiplayer/ServerGameWidget.py",
			"Multiplayer/DialogoEndGame.py",
			"Multiplayer/Widgets.py",
			"Multiplayer/__init__.py",
			"Multiplayer/Bala.py",
			"Multiplayer/Explosion.py",
			"Multiplayer/Jugador.py",
			"Multiplayer/ClientGameWidget.py",
			"Multiplayer/Globales.py",
			"Multiplayer/Juego.py"])])

import commands
commands.getoutput("chmod -R 755 /usr/local/share/JAMTank")
commands.getoutput("chmod 755 /usr/share/applications/JAMTank.desktop")
