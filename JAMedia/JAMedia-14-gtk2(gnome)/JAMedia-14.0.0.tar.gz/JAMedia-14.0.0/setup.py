#!/usr/bin/env python
# -*- coding: utf-8 -*-

from distutils.core import setup

setup(
	name = "JAMedia",
	version = "14.0.0",
	author = "Flavio Danesse",
	author_email = "fdanesse@gmail.com",
	url = "https://sites.google.com/site/sugaractivities/jamediaobjects/jam",
	license = "GPL3",

	scripts = ["jamedia_run", "jamedia_uninstall"],

	py_modules = ["JAMedia"],

	data_files =[
		("/usr/share/applications/", ["JAMedia.desktop"]),
		("",[
			"PlayerControls.py",
			"JAMedia.desktop",
			"setup.py",
			"Widgets.py",
			"PlayerList.py",
			"Toolbars.py",
			"MANIFEST",
			"COPYING",
			"Globales.py",
			"jamedia_uninstall",
			"JAMedia.py",
			"JAMediaPlayer.py",
			"setup.cfg",
			"AUTHORS",
			"jamedia_run"]),

		("Iconos/",[
			"Iconos/lista.svg",
			"Iconos/jamedia_cursor.svg",
			"Iconos/iconplay.svg",
			"Iconos/sonido.svg",
			"Iconos/help-2.svg",
			"Iconos/play.svg",
			"Iconos/siguiente.svg",
			"Iconos/agregar.svg",
			"Iconos/JAMediaCredits.svg",
			"Iconos/dialog-ok.svg",
			"Iconos/pausa.svg",
			"Iconos/button-cancel.svg",
			"Iconos/stop.svg",
			"Iconos/JAMedia-help.svg",
			"Iconos/rotar.svg",
			"Iconos/help-1.svg",
			"Iconos/JAMedia.svg",
			"Iconos/help-4.svg",
			"Iconos/help-3.svg",
			"Iconos/configurar.svg",
			"Iconos/video.svg"]),

		("JAMediaReproductor/",[
			"JAMediaReproductor/JAMediaReproductor.py",
			"JAMediaReproductor/__init__.py",
			"JAMediaReproductor/JAMediaStreamingReproductor.py",
			"JAMediaReproductor/JAMediaBins.py",
			"JAMediaReproductor/JAMediaGrabador.py"])])

import commands
commands.getoutput("chmod -R 755 /usr/local/share/JAMedia")
commands.getoutput("chmod 755 /usr/share/applications/JAMedia.desktop")
