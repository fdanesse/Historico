#!/usr/bin/env python
# -*- coding: utf-8 -*-

from distutils.core import setup

setup(
	name = "JAMediaTube",
	version = "9.0.0",
	author = "Flavio Danesse",
	author_email = "fdanesse@gmail.com",
	url = "https://sites.google.com/site/sugaractivities/jamediaobjects/jamediatube",
	license = "GPL3",

	scripts = ["jamediatube_run", "jamediatube_uninstall"],

	py_modules = ["JAMediaTube"],

	data_files =[
		("/usr/share/applications/", ["JAMediaTube.desktop"]),
		("",[
			"JAMediaTube.py",
			"TubeListDialog.py",
			"MANIFEST",
			"setup.py",
			"PanelTubeWidgets.py",
			"Widgets.py",
			"__init__.py",
			"SugarJAMediaTube.py",
			"JAMediaYoutube.py",
			"setup.cfg",
			"youtube-dl",
			"jamediatube_uninstall",
			"COPYING",
			"Globales.py",
			"JAMediaTube.desktop",
			"PanelTube.py",
			"jamediatube_run",
			"AUTHORS"]),

		("gdata/base/",[
			"gdata/base/__init__.py",
			"gdata/base/service.py"]),

		("gdata/spreadsheets/",[
			"gdata/spreadsheets/client.py",
			"gdata/spreadsheets/__init__.py",
			"gdata/spreadsheets/data.py"]),

		("gdata/",[
			"gdata/gauth.py",
			"gdata/test_config.py",
			"gdata/client.py",
			"gdata/__init__.py",
			"gdata/urlfetch.py",
			"gdata/auth.py",
			"gdata/service.py",
			"gdata/core.py",
			"gdata/apps_property.py",
			"gdata/data.py",
			"gdata/test_data.py",
			"gdata/sample_util.py"]),

		("gdata/apps/emailsettings/",[
			"gdata/apps/emailsettings/client.py",
			"gdata/apps/emailsettings/__init__.py",
			"gdata/apps/emailsettings/service.py",
			"gdata/apps/emailsettings/data.py"]),

		("gdata/alt/",[
			"gdata/alt/app_engine.py",
			"gdata/alt/__init__.py",
			"gdata/alt/appengine.py"]),

		("Iconos/",[
			"Iconos/JAMedia.svg",
			"Iconos/yt_videos_black.png",
			"Iconos/JAMedia-help.svg",
			"Iconos/button-cancel.svg",
			"Iconos/JAMediaTube.svg",
			"Iconos/video.svg",
			"Iconos/iconplay.svg",
			"Iconos/JAMediaTubeCredits.svg",
			"Iconos/dialog-ok.svg",
			"Iconos/play.svg",
			"Iconos/lista.svg",
			"Iconos/alejar.svg",
			"Iconos/help-1.svg",
			"Iconos/help-2.svg"]),

		("gdata/calendar/",[
			"gdata/calendar/client.py",
			"gdata/calendar/__init__.py",
			"gdata/calendar/service.py",
			"gdata/calendar/data.py"]),

		("atom/",[
			"atom/token_store.py",
			"atom/url.py",
			"atom/client.py",
			"atom/__init__.py",
			"atom/mock_http_core.py",
			"atom/auth.py",
			"atom/mock_http.py",
			"atom/mock_service.py",
			"atom/http_core.py",
			"atom/http.py",
			"atom/service.py",
			"atom/core.py",
			"atom/data.py",
			"atom/http_interface.py"]),

		("gdata/exif/",[
			"gdata/exif/__init__.py"]),

		("gdata/oauth/",[
			"gdata/oauth/__init__.py",
			"gdata/oauth/CHANGES.txt",
			"gdata/oauth/rsa.py"]),

		("gdata/Crypto/",[
			"gdata/Crypto/__init__.py",
			"gdata/Crypto/test.py"]),

		("gdata/geo/",[
			"gdata/geo/__init__.py",
			"gdata/geo/data.py"]),

		("gdata/apps/organization/",[
			"gdata/apps/organization/__init__.py",
			"gdata/apps/organization/service.py"]),

		("gdata/projecthosting/",[
			"gdata/projecthosting/client.py",
			"gdata/projecthosting/__init__.py",
			"gdata/projecthosting/data.py"]),

		("gdata/tlslite/integration/",[
			"gdata/tlslite/integration/ClientHelper.py",
			"gdata/tlslite/integration/HTTPTLSConnection.py",
			"gdata/tlslite/integration/__init__.py",
			"gdata/tlslite/integration/TLSAsyncDispatcherMixIn.py",
			"gdata/tlslite/integration/XMLRPCTransport.py",
			"gdata/tlslite/integration/IMAP4_TLS.py",
			"gdata/tlslite/integration/TLSSocketServerMixIn.py",
			"gdata/tlslite/integration/TLSTwistedProtocolWrapper.py",
			"gdata/tlslite/integration/AsyncStateMachine.py",
			"gdata/tlslite/integration/POP3_TLS.py",
			"gdata/tlslite/integration/SMTP_TLS.py",
			"gdata/tlslite/integration/IntegrationHelper.py"]),

		("JAMedia/GstWidgets/",[
			"JAMedia/GstWidgets/Widgets.py",
			"JAMedia/GstWidgets/__init__.py",
			"JAMedia/GstWidgets/VideoEfectos.py",
			"JAMedia/GstWidgets/Good.py"]),

		("gdata/opensearch/",[
			"gdata/opensearch/__init__.py",
			"gdata/opensearch/data.py"]),

		("JAMedia/Iconos/",[
			"JAMedia/Iconos/JAMediaCredits.svg",
			"JAMedia/Iconos/agregar.svg",
			"JAMedia/Iconos/JAMedia.svg",
			"JAMedia/Iconos/document-new.svg",
			"JAMedia/Iconos/stop.svg",
			"JAMedia/Iconos/JAMedia-help.svg",
			"JAMedia/Iconos/jamedia_cursor.svg",
			"JAMedia/Iconos/button-cancel.svg",
			"JAMedia/Iconos/pausa.svg",
			"JAMedia/Iconos/video.svg",
			"JAMedia/Iconos/siguiente.svg",
			"JAMedia/Iconos/controlslicer.svg",
			"JAMedia/Iconos/iconplay.svg",
			"JAMedia/Iconos/dialog-ok.svg",
			"JAMedia/Iconos/play.svg",
			"JAMedia/Iconos/document-open.svg",
			"JAMedia/Iconos/lista.svg",
			"JAMedia/Iconos/help-3.svg",
			"JAMedia/Iconos/sonido.svg",
			"JAMedia/Iconos/configurar.svg",
			"JAMedia/Iconos/clear.svg",
			"JAMedia/Iconos/help-4.svg",
			"JAMedia/Iconos/help-1.svg",
			"JAMedia/Iconos/help-2.svg",
			"JAMedia/Iconos/rotar.svg"]),

		("youtube_dl/",[
			"youtube_dl/PostProcessor.py",
			"youtube_dl/__init__.py",
			"youtube_dl/update.py",
			"youtube_dl/__main__.py",
			"youtube_dl/InfoExtractors.py",
			"youtube_dl/aes.py",
			"youtube_dl/YoutubeDL.py",
			"youtube_dl/utils.py",
			"youtube_dl/FileDownloader.py",
			"youtube_dl/version.py"]),

		("gdata/finance/",[
			"gdata/finance/__init__.py",
			"gdata/finance/service.py",
			"gdata/finance/data.py"]),

		("gdata/webmastertools/",[
			"gdata/webmastertools/__init__.py",
			"gdata/webmastertools/service.py",
			"gdata/webmastertools/data.py"]),

		("gdata/sites/",[
			"gdata/sites/client.py",
			"gdata/sites/__init__.py",
			"gdata/sites/data.py"]),

		("gdata/tlslite/utils/",[
			"gdata/tlslite/utils/PyCrypto_RC4.py",
			"gdata/tlslite/utils/Python_RC4.py",
			"gdata/tlslite/utils/entropy.c",
			"gdata/tlslite/utils/Python_AES.py",
			"gdata/tlslite/utils/hmac.py",
			"gdata/tlslite/utils/PyCrypto_AES.py",
			"gdata/tlslite/utils/codec.py",
			"gdata/tlslite/utils/__init__.py",
			"gdata/tlslite/utils/PyCrypto_RSAKey.py",
			"gdata/tlslite/utils/win32prng.c",
			"gdata/tlslite/utils/dateFuncs.py",
			"gdata/tlslite/utils/jython_compat.py",
			"gdata/tlslite/utils/keyfactory.py",
			"gdata/tlslite/utils/cipherfactory.py",
			"gdata/tlslite/utils/TripleDES.py",
			"gdata/tlslite/utils/Cryptlib_AES.py",
			"gdata/tlslite/utils/Cryptlib_RC4.py",
			"gdata/tlslite/utils/AES.py",
			"gdata/tlslite/utils/xmltools.py",
			"gdata/tlslite/utils/compat.py",
			"gdata/tlslite/utils/Python_RSAKey.py",
			"gdata/tlslite/utils/OpenSSL_TripleDES.py",
			"gdata/tlslite/utils/RSAKey.py",
			"gdata/tlslite/utils/ASN1Parser.py",
			"gdata/tlslite/utils/OpenSSL_RC4.py",
			"gdata/tlslite/utils/rijndael.py",
			"gdata/tlslite/utils/Cryptlib_TripleDES.py",
			"gdata/tlslite/utils/PyCrypto_TripleDES.py",
			"gdata/tlslite/utils/cryptomath.py",
			"gdata/tlslite/utils/RC4.py",
			"gdata/tlslite/utils/OpenSSL_AES.py",
			"gdata/tlslite/utils/OpenSSL_RSAKey.py"]),

		("gdata/codesearch/",[
			"gdata/codesearch/__init__.py",
			"gdata/codesearch/service.py"]),

		("gdata/apps/migration/",[
			"gdata/apps/migration/__init__.py",
			"gdata/apps/migration/service.py"]),

		("gdata/tlslite/",[
			"gdata/tlslite/messages.py",
			"gdata/tlslite/FileObject.py",
			"gdata/tlslite/VerifierDB.py",
			"gdata/tlslite/X509CertChain.py",
			"gdata/tlslite/constants.py",
			"gdata/tlslite/__init__.py",
			"gdata/tlslite/TLSConnection.py",
			"gdata/tlslite/SessionCache.py",
			"gdata/tlslite/api.py",
			"gdata/tlslite/Checker.py",
			"gdata/tlslite/BaseDB.py",
			"gdata/tlslite/Session.py",
			"gdata/tlslite/X509.py",
			"gdata/tlslite/HandshakeSettings.py",
			"gdata/tlslite/SharedKeyDB.py",
			"gdata/tlslite/errors.py",
			"gdata/tlslite/TLSRecordLayer.py",
			"gdata/tlslite/mathtls.py"]),

		("gdata/spreadsheet/",[
			"gdata/spreadsheet/__init__.py",
			"gdata/spreadsheet/text_db.py",
			"gdata/spreadsheet/service.py"]),

		("gdata/apps/",[
			"gdata/apps/__init__.py",
			"gdata/apps/service.py"]),

		("gdata/dublincore/",[
			"gdata/dublincore/__init__.py",
			"gdata/dublincore/data.py"]),

		("gdata/marketplace/",[
			"gdata/marketplace/client.py",
			"gdata/marketplace/__init__.py",
			"gdata/marketplace/data.py"]),

		("gdata/photos/",[
			"gdata/photos/__init__.py",
			"gdata/photos/service.py"]),

		("gdata/Crypto/Cipher/",[
			"gdata/Crypto/Cipher/AES.pyd",
			"gdata/Crypto/Cipher/XOR.pyd",
			"gdata/Crypto/Cipher/DES.pyd",
			"gdata/Crypto/Cipher/__init__.py",
			"gdata/Crypto/Cipher/RC5.pyd",
			"gdata/Crypto/Cipher/DES3.pyd",
			"gdata/Crypto/Cipher/ARC4.pyd",
			"gdata/Crypto/Cipher/CAST.pyd",
			"gdata/Crypto/Cipher/ARC2.pyd",
			"gdata/Crypto/Cipher/IDEA.pyd",
			"gdata/Crypto/Cipher/Blowfish.pyd"]),

		("gdata/contacts/",[
			"gdata/contacts/client.py",
			"gdata/contacts/__init__.py",
			"gdata/contacts/service.py",
			"gdata/contacts/data.py"]),

		("gdata/analytics/",[
			"gdata/analytics/client.py",
			"gdata/analytics/__init__.py",
			"gdata/analytics/service.py",
			"gdata/analytics/data.py"]),

		("gdata/youtube/",[
			"gdata/youtube/client.py",
			"gdata/youtube/__init__.py",
			"gdata/youtube/service.py",
			"gdata/youtube/data.py"]),

		("gdata/docs/",[
			"gdata/docs/client.py",
			"gdata/docs/__init__.py",
			"gdata/docs/service.py",
			"gdata/docs/data.py"]),

		("gdata/books/",[
			"gdata/books/__init__.py",
			"gdata/books/service.py",
			"gdata/books/data.py"]),

		("gdata/apps/groups/",[
			"gdata/apps/groups/__init__.py",
			"gdata/apps/groups/service.py"]),

		("gdata/notebook/",[
			"gdata/notebook/__init__.py",
			"gdata/notebook/data.py"]),

		("gdata/apps/adminsettings/",[
			"gdata/apps/adminsettings/__init__.py",
			"gdata/apps/adminsettings/service.py"]),

		("JAMedia/",[
			"JAMedia/BalanceWidget.py",
			"JAMedia/Widgets.py",
			"JAMedia/__init__.py",
			"JAMedia/Toolbars.py",
			"JAMedia/JAMedia.py",
			"JAMedia/BasePanel.py",
			"JAMedia/PlayerControls.py",
			"JAMedia/ProgressPlayer.py",
			"JAMedia/IzquierdaWidgets.py",
			"JAMedia/Globales.py",
			"JAMedia/JAMediaPlayerList.py",
			"JAMedia/Derecha.py",
			"JAMedia/PlayerList.py",
			"JAMedia/Izquierda.py"]),

		("youtube_dl/extractor/",[
			"youtube_dl/extractor/ted.py",
			"youtube_dl/extractor/ringtv.py",
			"youtube_dl/extractor/cnn.py",
			"youtube_dl/extractor/livestream.py",
			"youtube_dl/extractor/wat.py",
			"youtube_dl/extractor/justintv.py",
			"youtube_dl/extractor/tumblr.py",
			"youtube_dl/extractor/criterion.py",
			"youtube_dl/extractor/gametrailers.py",
			"youtube_dl/extractor/howcast.py",
			"youtube_dl/extractor/common.py",
			"youtube_dl/extractor/pbs.py",
			"youtube_dl/extractor/addanime.py",
			"youtube_dl/extractor/jukebox.py",
			"youtube_dl/extractor/mixcloud.py",
			"youtube_dl/extractor/sina.py",
			"youtube_dl/extractor/ro220.py",
			"youtube_dl/extractor/yahoo.py",
			"youtube_dl/extractor/weibo.py",
			"youtube_dl/extractor/googlesearch.py",
			"youtube_dl/extractor/infoq.py",
			"youtube_dl/extractor/redtube.py",
			"youtube_dl/extractor/youtube.py",
			"youtube_dl/extractor/__init__.py",
			"youtube_dl/extractor/teamcoco.py",
			"youtube_dl/extractor/pornotube.py",
			"youtube_dl/extractor/vimeo.py",
			"youtube_dl/extractor/gamespot.py",
			"youtube_dl/extractor/hypem.py",
			"youtube_dl/extractor/canalc2.py",
			"youtube_dl/extractor/freesound.py",
			"youtube_dl/extractor/condenast.py",
			"youtube_dl/extractor/jeuxvideo.py",
			"youtube_dl/extractor/hark.py",
			"youtube_dl/extractor/exfm.py",
			"youtube_dl/extractor/ooyala.py",
			"youtube_dl/extractor/roxwel.py",
			"youtube_dl/extractor/depositfiles.py",
			"youtube_dl/extractor/auengine.py",
			"youtube_dl/extractor/xhamster.py",
			"youtube_dl/extractor/cspan.py",
			"youtube_dl/extractor/mit.py",
			"youtube_dl/extractor/photobucket.py",
			"youtube_dl/extractor/myspass.py",
			"youtube_dl/extractor/steam.py",
			"youtube_dl/extractor/trilulilu.py",
			"youtube_dl/extractor/orf.py",
			"youtube_dl/extractor/ard.py",
			"youtube_dl/extractor/vine.py",
			"youtube_dl/extractor/ign.py",
			"youtube_dl/extractor/dailymotion.py",
			"youtube_dl/extractor/escapist.py",
			"youtube_dl/extractor/sohu.py",
			"youtube_dl/extractor/bandcamp.py",
			"youtube_dl/extractor/traileraddict.py",
			"youtube_dl/extractor/spiegel.py",
			"youtube_dl/extractor/flickr.py",
			"youtube_dl/extractor/metacafe.py",
			"youtube_dl/extractor/thisav.py",
			"youtube_dl/extractor/arte.py",
			"youtube_dl/extractor/veoh.py",
			"youtube_dl/extractor/ina.py",
			"youtube_dl/extractor/hotnewhiphop.py",
			"youtube_dl/extractor/xnxx.py",
			"youtube_dl/extractor/kankan.py",
			"youtube_dl/extractor/ehow.py",
			"youtube_dl/extractor/videofyme.py",
			"youtube_dl/extractor/c56.py",
			"youtube_dl/extractor/ustream.py",
			"youtube_dl/extractor/funnyordie.py",
			"youtube_dl/extractor/keek.py",
			"youtube_dl/extractor/bliptv.py",
			"youtube_dl/extractor/nbc.py",
			"youtube_dl/extractor/eighttracks.py",
			"youtube_dl/extractor/worldstarhiphop.py",
			"youtube_dl/extractor/rbmaradio.py",
			"youtube_dl/extractor/statigram.py",
			"youtube_dl/extractor/wimp.py",
			"youtube_dl/extractor/unistra.py",
			"youtube_dl/extractor/slashdot.py",
			"youtube_dl/extractor/dotsub.py",
			"youtube_dl/extractor/myvideo.py",
			"youtube_dl/extractor/rtlnow.py",
			"youtube_dl/extractor/generic.py",
			"youtube_dl/extractor/vevo.py",
			"youtube_dl/extractor/nba.py",
			"youtube_dl/extractor/instagram.py",
			"youtube_dl/extractor/appletrailers.py",
			"youtube_dl/extractor/brightcove.py",
			"youtube_dl/extractor/liveleak.py",
			"youtube_dl/extractor/facebook.py",
			"youtube_dl/extractor/youporn.py",
			"youtube_dl/extractor/muzu.py",
			"youtube_dl/extractor/xvideos.py",
			"youtube_dl/extractor/breakcom.py",
			"youtube_dl/extractor/canalplus.py",
			"youtube_dl/extractor/tutv.py",
			"youtube_dl/extractor/collegehumor.py",
			"youtube_dl/extractor/mtv.py",
			"youtube_dl/extractor/youjizz.py",
			"youtube_dl/extractor/tudou.py",
			"youtube_dl/extractor/dreisat.py",
			"youtube_dl/extractor/archiveorg.py",
			"youtube_dl/extractor/vbox7.py",
			"youtube_dl/extractor/soundcloud.py",
			"youtube_dl/extractor/comedycentral.py",
			"youtube_dl/extractor/tf1.py",
			"youtube_dl/extractor/youku.py",
			"youtube_dl/extractor/zdf.py",
			"youtube_dl/extractor/googleplus.py",
			"youtube_dl/extractor/stanfordoc.py"]),

		("gdata/apps/audit/",[
			"gdata/apps/audit/__init__.py",
			"gdata/apps/audit/service.py"]),

		("gdata/contentforshopping/",[
			"gdata/contentforshopping/client.py",
			"gdata/contentforshopping/__init__.py",
			"gdata/contentforshopping/data.py"]),

		("gdata/Crypto/Protocol/",[
			"gdata/Crypto/Protocol/__init__.py",
			"gdata/Crypto/Protocol/AllOrNothing.py",
			"gdata/Crypto/Protocol/Chaffing.py"]),

		("gdata/media/",[
			"gdata/media/__init__.py",
			"gdata/media/data.py"]),

		("JAMedia/JAMediaReproductor/",[
			"JAMedia/JAMediaReproductor/__init__.py",
			"JAMedia/JAMediaReproductor/JAMediaReproductor.py",
			"JAMedia/JAMediaReproductor/JAMediaBins.py",
			"JAMedia/JAMediaReproductor/JAMediaGrabador.py"]),

		("gdata/Crypto/Util/",[
			"gdata/Crypto/Util/randpool.py",
			"gdata/Crypto/Util/RFC1751.py",
			"gdata/Crypto/Util/__init__.py",
			"gdata/Crypto/Util/number.py",
			"gdata/Crypto/Util/test.py"]),

		("gdata/Crypto/PublicKey/",[
			"gdata/Crypto/PublicKey/ElGamal.py",
			"gdata/Crypto/PublicKey/__init__.py",
			"gdata/Crypto/PublicKey/pubkey.py",
			"gdata/Crypto/PublicKey/qNEW.py",
			"gdata/Crypto/PublicKey/RSA.py",
			"gdata/Crypto/PublicKey/DSA.py"]),

		("gdata/blogger/",[
			"gdata/blogger/client.py",
			"gdata/blogger/__init__.py",
			"gdata/blogger/service.py",
			"gdata/blogger/data.py"]),

		("gdata/acl/",[
			"gdata/acl/__init__.py",
			"gdata/acl/data.py"]),

		("gdata/health/",[
			"gdata/health/__init__.py",
			"gdata/health/service.py"]),

		("gdata/calendar_resource/",[
			"gdata/calendar_resource/client.py",
			"gdata/calendar_resource/__init__.py",
			"gdata/calendar_resource/data.py"]),

		("gdata/Crypto/Hash/",[
			"gdata/Crypto/Hash/MD5.py",
			"gdata/Crypto/Hash/MD2.pyd",
			"gdata/Crypto/Hash/HMAC.py",
			"gdata/Crypto/Hash/__init__.py",
			"gdata/Crypto/Hash/RIPEMD.pyd",
			"gdata/Crypto/Hash/SHA256.pyd",
			"gdata/Crypto/Hash/MD4.pyd",
			"gdata/Crypto/Hash/SHA.py"])])

import commands
commands.getoutput("chmod -R 755 /usr/local/share/JAMediaTube")
commands.getoutput("chmod 755 /usr/share/applications/JAMediaTube.desktop")
